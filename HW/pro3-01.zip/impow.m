function [I2] = impow(I1, c, g)
I2 = I1;
[m n] = size(I1);
for i = 1:m
    for j = 1:n
        I2(i,j) = c*power(double(I1(i, j)), g);
    end
end