function [I2] = imlog(I1, c)
I2 = I1;
[m n] = size(I1);
for i = 1:m
    for j = 1:n
        I2(i,j) = c*log2(double(I1(i,j)) + 1);
    end
end
